<?php

namespace App\View\Components;

use Closure;
use Illuminate\Contracts\View\View;
use Illuminate\View\Component;

class tw_button_a extends Component
{
    /**
     * Create a new component instance.
     */
    public $bgColor = 'blue';
    public $text = 'Submit';
    public $icon;
    public $route = '/';
    public $classFix = '';
    public $class;

    public function __construct($bgColor, $text, $route, $icon = null, $class = null)
    {
        $this->bgColor = $bgColor ?? $bgColor;
        $this->text = $text ?? $text;
        $this->route = $route ?? $route;
        $this->icon = $icon;

        $this->class = $class ?? $class;
        $this->classFix = "inline-flex items-center justify-center min-w-20 bg-$this->bgColor-500 hover:bg-$this->bgColor-600 active:bg-$this->bgColor-700 focus:outline-none focus:ring focus:ring-$this->bgColor-300 text-white rounded-md p-2";
    }

    /**
     * Get the view / contents that represent the component.
     */
    public function render(): View|Closure|string
    {
        if ($this->icon) {
            $iconPath = storage_path('app/public/images/app/icons/outline/' . $this->icon . '.svg');
            $icon = file_exists($iconPath) ? file_get_contents($iconPath) : null;
        }
        return view('components.tw_button_a', [
            'bgColor' => $this->bgColor,
            'text' => $this->text,
            'route' => $this->route,
            'icon' => $icon,
            'classFix' => $this->classFix,
            'class' => $this->class,
        ]);
    }
}
